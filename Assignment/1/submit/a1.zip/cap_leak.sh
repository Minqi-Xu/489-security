./cap_leak "echo secrete message | sudo tee -a /etc/zzz"
