./catall "/etc/important;rm /etc/important"
